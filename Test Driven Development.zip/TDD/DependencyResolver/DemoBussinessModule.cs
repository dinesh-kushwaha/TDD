﻿using Demo.Bussiness.Layer;
using Ninject.Modules;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DependencyResolver
{
    public class DemoBussinessModule : NinjectModule
    {
        public override void Load()
        {
            Bind<IDemoBussinessClass>().To<DemoBussinessClass>();
        }
    }
}
