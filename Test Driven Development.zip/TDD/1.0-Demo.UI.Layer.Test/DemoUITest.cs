﻿using Demo.UI.Layer;
using Ninject;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1._0_Demo.UI.Layer.Test
{
    [TestFixture]
    public class DemoUITest 
    {

        [SetUp]
        public void TestSetUp()
        {

        }

        [Test]
        public void Test1()
        {
            IKernel _kernel = KernelManager.Instance.Kernel;
            var demoUIClass = _kernel.Get<IDemoUIClass>();
            var message = demoUIClass.GetMessage();
            var result = "This is a message from the bottom layer with connectionstring Dinesh Kushwaha";
            Assert.AreEqual(message, result);
        }

        [Test]
        public void Test2()
        {

        }

        [TearDown]
        public void TestTearDown()
        {

        }
    }
}
