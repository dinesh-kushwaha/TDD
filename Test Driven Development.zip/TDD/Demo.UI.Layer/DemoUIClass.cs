﻿using Demo.Bussiness.Layer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo.UI.Layer
{
    public class DemoUIClass : IDemoUIClass
    {
        private readonly IDemoBussinessClass _demoBussinessClass = null;

        public DemoUIClass(IDemoBussinessClass demoBussinessClass)
        {
            this._demoBussinessClass = demoBussinessClass;
        }

        public string GetMessage()
        {
            return _demoBussinessClass.GetMessage();
        }
    }
}
