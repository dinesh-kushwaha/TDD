﻿using Demo.DataAccess.Layer;
using Ninject.Modules;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DependencyResolver
{

    public class DemoDataAccessModule : NinjectModule
    {
        private readonly string _connectionString=null;
        public DemoDataAccessModule(string connectionString)
        {
            this._connectionString = connectionString;
        }
        public override void Load()
        {
            Bind<IDemoDataAccessClass>().To<DemoDataAccessClass>()
                .WithConstructorArgument("connectionString", _connectionString);
        }
    }
}
