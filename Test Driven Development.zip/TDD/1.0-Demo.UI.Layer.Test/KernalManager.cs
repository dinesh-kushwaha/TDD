﻿using Ninject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1._0_Demo.UI.Layer.Test
{
    public sealed class KernelManager
    {
        private static volatile KernelManager instance;
        private static object syncRoot = new Object();
        private IKernel _kernel = null;
        private KernelManager() { }

        public static KernelManager Instance
        {
            get
            {
                if (instance == null)
                {
                    lock (syncRoot)
                    {
                        if (instance == null)
                            instance = new KernelManager();
                    }
                }

                return instance;
            }
        }

        public void SetKernel(IKernel kernel)
        {
            this._kernel = kernel;
        }

        public IKernel Kernel
        {
            get
            {
                return _kernel;
            }
        }
    }

}
