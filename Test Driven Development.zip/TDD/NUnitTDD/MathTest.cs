﻿using NUnit.Framework;

namespace NUnitTDD
{
    [TestFixture]
    public class MathTest
    {
        [SetUp]
        public void TestSetUp()
        {

        }

        [Test]
        public void Test1()
        {

        }

        [TearDown]
        public void TestTearDown()
        {

        }

    }
}
