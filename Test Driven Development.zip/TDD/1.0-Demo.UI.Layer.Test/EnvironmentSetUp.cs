﻿using Demo.UI.Layer.Ioc;
using DependencyResolver;
using Ninject;
using Ninject.Modules;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1._0_Demo.UI.Layer.Test
{
    [SetUpFixture]
    public class EnvironmentSetUp
    {
        [OneTimeSetUpAttribute]
        public void RunBeforeAnyTests()
        {
            IKernel kernel = new StandardKernel(new DemoUIModule());
            var modules = new List<INinjectModule>
            {
                new DemoBussinessModule(),
                new DemoDataAccessModule("Dinesh Kushwaha")
            };
            kernel.Load(modules);
            KernelManager.Instance.SetKernel(kernel);
           
        }

        [OneTimeTearDown]
        public void RunAfterAnyTests()
        {
           
        }
    }
}
