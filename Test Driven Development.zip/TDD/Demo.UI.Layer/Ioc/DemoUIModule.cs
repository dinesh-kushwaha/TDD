﻿using Demo.Bussiness.Layer;
//using Demo.DataAccess.Layer;
using Ninject.Modules;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo.UI.Layer.Ioc
{
    public class DemoUIModule : NinjectModule
    {
        public override void Load()
        {
            Bind<IDemoUIClass>().To<DemoUIClass>();
            //Bind<IDemoBussinessClass>().To<DemoBussinessClass>();
            //Bind<IDemoDataAccessClass>().To<DemoDataAccessClass>();
        }
    }
}
