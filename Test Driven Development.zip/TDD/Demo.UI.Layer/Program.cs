﻿using Demo.UI.Layer;
using Demo.UI.Layer.Ioc;
using DependencyResolver;
using Ninject;
using Ninject.Modules;
using System.Collections.Generic;

public class Program
{
    static void Main(string[] args)
    {
        //================================================================
        //IKernel kernelAproch1 = new StandardKernel(new DemoUIModule());

        //var topClass = kernelAproch1.Get<IDemoUIClass>();
        //var message = topClass.GetMessage();
        //System.Console.WriteLine(message);

        //=====================================================================
        IKernel kernelAproch2 = new StandardKernel(new DemoUIModule());
        var modules = new List<INinjectModule>
            {
                new DemoBussinessModule(),
                new DemoDataAccessModule("Dinesh Kushwaha")
            };

        kernelAproch2.Load(modules);

        var topClassAp2 = kernelAproch2.Get<IDemoUIClass>();
        var messageAp2 = topClassAp2.GetMessage();
        System.Console.WriteLine(messageAp2);

        System.Console.WriteLine("Press enter to continue...");
        System.Console.ReadLine();
        //========================================================================
    }
}