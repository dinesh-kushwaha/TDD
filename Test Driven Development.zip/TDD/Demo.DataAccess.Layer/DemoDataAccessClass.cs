﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo.DataAccess.Layer
{
    public class DemoDataAccessClass: IDemoDataAccessClass
    {
        private readonly string _connectionString = null;
        public DemoDataAccessClass(string connectionString)
        {
            this._connectionString = connectionString;
        }
        public string GetMessage()
        {
            return string.Format("This is a message from the bottom layer with connectionstring {0}", _connectionString);
        }
    }
}
