﻿using Demo.DataAccess.Layer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo.Bussiness.Layer
{
    public class DemoBussinessClass : IDemoBussinessClass
    {
        private IDemoDataAccessClass _demoDataAccessClass = null;

        public DemoBussinessClass(IDemoDataAccessClass demoDataAccessClass)
        {
            this._demoDataAccessClass = demoDataAccessClass;
        }
        public string GetMessage()
        {
            return _demoDataAccessClass.GetMessage();
        }
    }
}
